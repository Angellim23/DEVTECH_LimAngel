<!DOCTYPE html>
<html>
<head>
    <title>PHP Handling Forms</title>
</head>
<body>
    <h2>PHP Handling Forms</h2>
    <form action="postform_submitted.php" method="post">
        <label for="name">My name is:</label>
        <input type="text" id="name" name="name"><br><br>

        <label for="movie">My favourite movie is:</label>
        <input type="text" id="movie" name="movie"><br><br>

        <label for="degree">My degree is:</label>
        <select id="degree" name="degree">
            <option value="Bachelor">Bachelor</option>
            <option value="Master">Master</option>
            <option value="PhD">PhD</option>
        </select><br><br>

        <label>Gender:</label>
        <input type="radio" id="male" name="gender" value="Male">
        <label for="male">Male</label>
        <input type="radio" id="female" name="gender" value="Female">
        <label for="female">Female</label><br><br>

        <label for="units">My favourite unit(s):</label>
        <select id="units" name="units[]" multiple>
            <option value="Poti">Poti</option>
            <option value="IP">IP</option>
        </select><br><br>

        <input type="submit" value="Submit">
    </form>
</body>
</html>
