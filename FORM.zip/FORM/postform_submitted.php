<?php
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $name = $_POST['name'];
    $movie = $_POST['movie'];
    $degree = $_POST['degree'];
    $gender = $_POST['gender'];
    $subject = $_POST['unit'];

    echo "<h2>postform_submitted.php</h2>";
    echo "<p>Hello " .($name) . "</p>";
    echo "<p>You like movie \"" . ($movie) . "\" </p>";
    echo "<p>You are enrolled in " . ($degree) . "'s Degree.</p>";
    echo "<p>Your gender is " . ($gender) . ".</p>";
    echo "<p>Your unit is " . ($unit) . ".</p>";
} else {
    echo "<p>Invalid submission.</p>";
}
?>

