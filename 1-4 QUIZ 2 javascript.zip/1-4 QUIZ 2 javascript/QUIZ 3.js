let num = -5;
if (num > 0) {
    console.log("The number is positive.");
} else {
    console.log("The number is not positive.");
}

// ANGEL MAE A. LIM
// T2023-0096
