let vehicle = {
    Name: "Honda",
    Model: "mobilio",
    Color: "White",
   }
   let vehicle2 = {
    Name: "Toyota",
    Model: "fortuner",
    Color: "Blue"
   }
   let vehicle3 = {
      Name: "Suzuki",
      Model: "swift",
      Color: "Red"
   };

// ANGEL MAE A. LIM
// T2023-0096
