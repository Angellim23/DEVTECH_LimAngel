class Vehicle {
    constructor (make, model, year, ownername) {
     this.make = make;
     this.model = model;
     this.year = year;
     this.ownername = ownername;
     
    }
    displayDetails() {
     console.log(`make: ${this.make}`);
     console.log(`model: ${this.model}`);
     console.log(`year: ${this.year}`);
     console.log(`ownername: ${this.ownername}`);
    
     
    }
 }
 
 class Car extends Vehicle {
     constructor(make,model,year,ownername) {
         super(make,model,year,ownername);
         this.doors = doors;
     }
     displayDetails() {
         super.displayDetails();
         console.log('Doors: ${this.doors}');
     }
 }
 //Create an instance of the vehicle class
 const vehicle = new Vehicle('Ford', 'F-150', 2020, 'Joshua');
 
 //Display vehicle details
 console.log('Vehicle Details:');
 vehicle.displayDetails();
 
 //Create an instance of the Car class
 const car = new Car('Honda', 'Accord', 2023, 'Rica', 4);
 
 //Display car details
 console.log('\nCar Details:');
 car.displayDetails();

 // ANGEL MAE A. LIM
 // T2023-0096