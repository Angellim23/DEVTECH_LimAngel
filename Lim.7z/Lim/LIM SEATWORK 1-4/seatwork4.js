//Create an empty object
let obj = {};

//create an object named person
let person = {
 name: "Patricia",
 age: 96,
}

//set  person as the prototype of obj
Object.setPrototypeOf(obj, person);

//print the prototype of obj
console.log(Object.getPrototypeOf(obj));

//Output: { name: 'Vincent',  age: 56 }

//check if thw prototype of obj
// is equal to the person object
console.log(Object.getPrototypeOf(obj) == person)

//output: true

// ANGEL MAE A. LIM
 // T2023-0096