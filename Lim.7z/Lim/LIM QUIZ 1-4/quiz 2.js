let num1 = 100;
let num2 = 20;
if (num1 > num2) {
    console.log("num1 is greater.");
} else {
    console.log("num2 is greater.");
}

// ANGEL MAE A. LIM
// T2023-0096
