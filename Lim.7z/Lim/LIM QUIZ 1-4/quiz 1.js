 // assign the value
 let num = 6;
 if (num % 2 ==0) {
    console.log("The number is even.");
    
 
 } else {
    console.log("The number is odd");
 }

 // ANGEL MAE A. LIM
 // T2023-0096