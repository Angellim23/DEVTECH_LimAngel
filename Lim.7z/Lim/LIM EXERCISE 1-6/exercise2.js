// Define a JavaScript function called month_name with parameter dt
var month_name = function(dt){
    // Define in array containing names of months 
    mlist = [ "January", "February", "March", "April", "May","June","July","August","September", "Novebver","December"];
    // Return the name of the month corresponding to the month index of the provide date
    return mlist[dt.getMonth()];
};
// Output the name of the month for the provided date "10/11/2009"
console.log(month_name(new Date("01/11/2009")));
// Output name of the month for the provided date "11/13/2014"
console.log(month_name(new Date ("02/13/2014")));