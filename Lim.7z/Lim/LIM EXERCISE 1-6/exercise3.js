// Define a JavaScript function called getDaysInMonth with parameters month and year
var getDaysInMonth = function(month, year){
    // Get the number of days in the specified month and year
    return new Date(year, month, 0).getDate();
    // Here January is 0 based 
    // return new Date(year, month+1, 0). getDate();
};
// Output the number of days in January 2012
console.log(getDaysInMonth(1, 2012));
// Output the number of days in February 2012
console.log(getDaysInMonth(2, 2012));
// Output the number od days in September 2012
console.log(getDaysInMonth(9, 2012));
// Output the number of days in December 2012
console.log(getDaysInMonth(12, 2012));
// Outpur the number of days in March 2012
console.log(getDaysInMonth(6, 2012));